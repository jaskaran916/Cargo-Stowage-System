from fastapi import FastAPI
from .routers import search, waste, simulate, import_export, logs

app = FastAPI()

app.include_router(api_router)
app.include_router(search.router)
app.include_router(waste.router)
app.include_router(simulate.router)
app.include_router(import_export.router)
app.include_router(logs.router)

@app.get("/")
async def root():
    return {"message": "Welcome to the Cargo Stowage Management API"}