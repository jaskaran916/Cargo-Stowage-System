from fastapi import APIRouter

router = APIRouter()

@router.get("/search")
async def search_items(query: str):
    return {"message": f"Searching for {query}"}