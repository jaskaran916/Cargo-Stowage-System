from fastapi import APIRouter

router = APIRouter()

@router.get("/simulate")
async def simulate_process():
    return {"message": "Simulation started"}