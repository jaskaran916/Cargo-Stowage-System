from fastapi import APIRouter

router = APIRouter()

@router.get("/waste")
async def get_waste_data():
    return {"message": "Waste data retrieved"}