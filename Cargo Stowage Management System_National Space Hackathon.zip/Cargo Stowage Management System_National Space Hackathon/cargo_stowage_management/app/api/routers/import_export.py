from fastapi import APIRouter

router = APIRouter()

@router.post("/import")
async def import_data(data: dict):
    return {"message": "Data imported successfully"}

@router.post("/export")
async def export_data():
    return {"message": "Data exported successfully"}